MaterialKitWP
===

This is a Material Bootstrap WordPress theme based off the free Material Kit UI provided by [Creative Tim](http://www.creative-tim.com/product/material-kit)
