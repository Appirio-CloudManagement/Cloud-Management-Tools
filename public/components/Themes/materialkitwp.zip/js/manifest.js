// bootstrap bower package scripts
//= include ../bower_components/bootstrap-sass/assets/javascripts/bootstrap.min.js