jQuery(document).ready(function($){
  $(window).on('scroll', materialKit.checkScrollForTransparentNavbar);
});